
# ♾️ Eternal MPG

Дипломатическая платформа для виртуально-политической интеграции.

## 🌍 О проекте

Eternal MPG — это интерактивная платформа, где участники могут:
- Управлять виртуальными государствами
- Публиковать дипломатические документы и декларации
- Вести переговоры и заключать союзы
- Участвовать в решении глобальных кризисов

## 🚀 Быстрый старт

### Локальная разработка

```bash
# Клонировать репозиторий
git clone https://github.com/your-username/eternal-mpg.git
cd eternal-mpg

# Установить зависимости
npm install

# Запустить dev-сервер
npm run dev
```

Откройте http://localhost:3000 в браузере.

### Сборка

```bash
npm run build
```

Собранные файлы будут в папке `dist/`.

## ☁️ Деплой на Cloudflare Pages

### Автоматический деплой (через GitHub)

1. Форкните этот репозиторий
2. В Cloudflare Pages создайте новый проект
3. Подключите GitHub репозиторий
4. Настройки сборки:
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
   - **Node.js version:** `20`

### Ручной деплой

```bash
# Установите Wrangler CLI
npm install -g wrangler

# Авторизуйтесь
wrangler login

# Деплой
npm run deploy
```

## 🔧 Технологии

- **React 18** — UI библиотека
- **TypeScript** — типизация
- **Vite** — сборщик
- **CSS Custom Properties** — стилизация
- **Persistent Storage API** — хранение данных

## 📁 Структура проекта

```
├── public/              # Статические файлы
├── src/
│   ├── components/      # Переиспользуемые компоненты
│   ├── features/        # Функциональные модули
│   │   ├── auth/        # Аутентификация
│   │   ├── posts/       # Публикации
│   │   ├── admin/       # Панель администратора
│   │   └── site-news/   # Новости платформы
│   ├── services/        # Сервисы (БД, ИИ)
│   ├── styles/          # Глобальные стили
│   ├── types/           # TypeScript типы
│   └── utils/           # Утилиты
├── package.json
├── vite.config.ts
└── tsconfig.json
```

## 🤝 Участие

Мы приветствуем вклад в проект! Пожалуйста:

1. Форкните проект
2. Создайте feature-branch (`git checkout -b feature/amazing`)
3. Закоммитьте изменения (`git commit -m 'Add amazing feature'`)
4. Запушьте ветку (`git push origin feature/amazing`)
5. Откройте Pull Request

## 📄 Лицензия

MIT License — см. [LICENSE](LICENSE) для деталей.

## 📧 Контакты

- **Сайт:** [eternal-mpg.pages.dev](https://eternal-mpg.pages.dev)
- **GitHub:** [github.com/your-username/eternal-mpg](https://github.com/your-username/eternal-mpg)

---

<p align="center">
  <b>♾️ Eternal MPG</b> — Где рождаются государства и пишется история
</p>
