
# 🚀 Руководство по деплою

## Cloudflare Pages + GitHub

### Шаг 1: Создайте репозиторий на GitHub

1. Зайдите на [github.com](https://github.com)
2. Создайте новый репозиторий (например, `eternal-mpg`)
3. Загрузите код проекта

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/eternal-mpg.git
git push -u origin main
```

### Шаг 2: Подключите Cloudflare Pages

1. Зайдите в [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Перейдите в **Pages** → **Create a project**
3. Выберите **Connect to Git**
4. Авторизуйтесь с GitHub и выберите репозиторий

### Шаг 3: Настройки сборки

| Параметр | Значение |
|----------|----------|
| Production branch | `main` |
| Build command | `npm run build` |
| Build output directory | `dist` |
| Root directory | `/` |
| Node.js version | `20` |

### Шаг 4: Переменные окружения (опционально)

В настройках проекта Cloudflare Pages добавьте:

| Variable | Value |
|----------|-------|
| `NODE_VERSION` | `20` |

### Шаг 5: Деплой

Нажмите **Save and Deploy**. После завершения сборки ваш сайт будет доступен по адресу:
```
https://eternal-mpg.pages.dev
```

### Кастомный домен

1. В настройках Pages перейдите в **Custom domains**
2. Нажмите **Set up a custom domain**
3. Введите ваш домен (например, `mpg.yourdomain.com`)
4. Следуйте инструкциям по настройке DNS

## Локальная разработка

```bash
# Установка
npm install

# Dev сервер
npm run dev

# Просмотр собранного проекта
npm run build
npm run preview
```

## Структура деплоя

```
dist/                    # Сборка
├── assets/             # JS/CSS с хэшами
├── _redirects          # SPA роутинг
├── favicon.svg
├── manifest.json
├── robots.txt
└── index.html
```

## Troubleshooting

### 404 при обновлении страницы
Убедитесь, что файл `_redirects` в папке `public/` содержит:
```
/*    /index.html   200
```

### Сборка падает с ошибкой
Проверьте версию Node.js (нужна 18+):
```bash
node --version
```

### Медленная загрузка
Vite автоматически оптимизирует и сжимает ресурсы. Убедитесь, что в `vite.config.ts` включена минификация.
